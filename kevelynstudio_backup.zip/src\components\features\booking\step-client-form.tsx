"use client";

import { useBooking } from "@/context/booking-context";
import { GlassCard } from "@/components/ui/glass-card";
import { Input } from "@/components/ui/input"; // We need to create this basic UI atom
import { ChevronRight } from "lucide-react";
import { useState } from "react";

export function StepClientForm() {
    const { state, setClientData, setSensory, nextStep, prevStep } = useBooking();

    // Local state for form handling before submitting to context
    const [formData, setFormData] = useState({
        name: state.clientData.name,
        email: state.clientData.email,
        phone: state.clientData.phone,
        music: state.sensory.musicGenre,
        drink: state.sensory.drink
    });

    const handleChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async () => {
        setIsSubmitting(true);
        try {
            // Construct start time
            // state.date is Date object (00:00:00), state.timeSlot is "HH:MM"
            const fullDate = new Date(state.date!);
            const [hours, minutes] = state.timeSlot!.split(':').map(Number);
            fullDate.setHours(hours, minutes, 0, 0);

            const payload = {
                clientData: {
                    name: formData.name,
                    email: formData.email,
                    phone: formData.phone
                },
                sensoryData: {
                    musicGenre: formData.music,
                    drink: formData.drink
                },
                appointmentData: {
                    professionalId: state.professional!.id,
                    serviceId: state.service!.id,
                    date: fullDate.toISOString()
                }
            };

            const res = await fetch('/api/bookings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                // Success!
                // We could redirect to a success page or show a modal
                alert("Agendamento Confirmado! (Demo)");
                // Reset or Redirect
            } else {
                alert("Erro ao agendar.");
            }
        } catch (e) {
            console.error(e);
            alert("Erro de conexão.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const isValid = formData.name && formData.email && formData.phone;

    return (
        <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-serif text-white text-center mb-2">Finalizar Agendamento</h2>
            <p className="text-white/50 text-center mb-10">Preencha seus dados para confirmarmos sua experiência.</p>

            <GlassCard className="space-y-6">
                <div className="space-y-4">
                    <h3 className="text-xs uppercase tracking-widest text-primary mb-4">Dados Pessoais</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                        <Input
                            placeholder="Nome Completo"
                            value={formData.name}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('name', e.target.value)}
                        />
                        <Input
                            placeholder="Telefone / WhatsApp"
                            value={formData.phone}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('phone', e.target.value)}
                        />
                    </div>
                    <Input
                        placeholder="E-mail"
                        type="email"
                        value={formData.email}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('email', e.target.value)}
                    />
                </div>

                <div className="pt-6 border-t border-white/10 space-y-4">
                    <h3 className="text-xs uppercase tracking-widest text-primary mb-4">Experiência Sensorial (Opcional)</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                        <select
                            className="bg-white/5 border border-white/10 rounded-lg p-3 text-white focus:border-primary outline-none [&>option]:text-black"
                            value={formData.music}
                            onChange={(e: React.ChangeEvent<HTMLSelectElement>) => handleChange('music', e.target.value)}
                        >
                            <option value="">Estilo Musical Favorito</option>
                            <option value="pop">Pop Internacional</option>
                            <option value="mpb">MPB / Calma</option>
                            <option value="eletronica">Eletrônica Lounge</option>
                            <option value="sertanejo">Sertanejo</option>
                            <option value="jazz">Jazz / Blues</option>
                        </select>

                        <select
                            className="bg-white/5 border border-white/10 rounded-lg p-3 text-white focus:border-primary outline-none [&>option]:text-black"
                            value={formData.drink}
                            onChange={(e: React.ChangeEvent<HTMLSelectElement>) => handleChange('drink', e.target.value)}
                        >
                            <option value="">Bebida de Boas-vindas</option>
                            <option value="agua">Água com Gás</option>
                            <option value="cafe">Café Espresso</option>
                            <option value="champagne">Espumante</option>
                            <option value="cha">Chá Especial</option>
                        </select>
                    </div>
                </div>

                <div className="pt-8 flex justify-between items-center">
                    <button onClick={prevStep} className="text-white/50 hover:text-white px-4">
                        Voltar
                    </button>
                    <button
                        disabled={!isValid || isSubmitting}
                        onClick={handleSubmit}
                        className="bg-primary text-black px-8 py-3 rounded-full font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center gap-2"
                    >
                        {isSubmitting ? "Confirmando..." : "Confirmar e Agendar"} <ChevronRight className="w-4 h-4" />
                    </button>
                </div>
            </GlassCard>
        </div>
    );
}
