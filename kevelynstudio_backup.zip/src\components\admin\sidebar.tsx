"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
    LayoutDashboard,
    Calendar,
    Users,
    BookOpen,
    Settings,
    Sparkles,
    ListMusic,
    MessageSquare,
    LogOut
} from "lucide-react";
import { cn } from "@/lib/cn";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

const MENU_ITEMS = [
    { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { label: "Agenda", href: "/admin/calendar", icon: Calendar },
    { label: "Clientes", href: "/admin/clients", icon: Users },
    { label: "Cursos", href: "/admin/courses", icon: BookOpen },
    { label: "Metodologia", href: "/admin/methodology", icon: Sparkles }, // New
    { label: "Menu Serviços", href: "/admin/services", icon: ListMusic }, // New
    { label: "Depoimentos", href: "/admin/testimonials", icon: MessageSquare }, // New
    { label: "Configurações", href: "/admin/settings", icon: Settings },
];

export function Sidebar() {
    const pathname = usePathname();
    const supabase = createClient();
    const router = useRouter();

    async function handleLogout() {
        await supabase.auth.signOut();
        router.push("/login"); // Middleware would redirect anyway, but this is faster UX
        router.refresh();
    }

    return (
        <aside className="w-64 h-screen bg-[#050505] border-r border-white/10 flex flex-col fixed left-0 top-0 overflow-y-auto z-50">
            {/* Header */}
            <div className="p-8 border-b border-white/5">
                <Link href="/" className="block">
                    <h1 className="font-serif text-xl text-white tracking-tight">
                        KEVELYN<br />STUDIO
                        <span className="text-gold text-xs block mt-1 tracking-widest font-sans">ADMIN</span>
                    </h1>
                </Link>
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-4 space-y-2">
                {MENU_ITEMS.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 group",
                                isActive
                                    ? "bg-white/10 text-white"
                                    : "text-white/40 hover:text-white hover:bg-white/5"
                            )}
                        >
                            <item.icon className={cn(
                                "w-5 h-5 transition-colors",
                                isActive ? "text-primary " : "text-white/30 group-hover:text-primary"
                            )} />
                            <span className="font-medium text-sm tracking-wide">
                                {item.label}
                            </span>
                        </Link>
                    )
                })}
            </nav>

            {/* Footer / Logout */}
            <div className="p-4 border-t border-white/5">
                <button
                    onClick={handleLogout}
                    className="flex items-center gap-3 px-4 py-3 w-full text-white/40 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors"
                >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium text-sm tracking-wide">Sair</span>
                </button>
            </div>
        </aside>
    );
}
