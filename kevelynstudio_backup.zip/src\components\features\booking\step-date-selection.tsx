"use client";

import { useBooking } from "@/context/booking-context";
import { PROFESSIONALS } from "@/lib/data-professionals";
import { GlassCard } from "@/components/ui/glass-card";
import { useState, useEffect } from "react";
import Image from "next/image";
import { cn } from "@/lib/cn";
import { ChevronRight, Calendar as CalendarIcon, Clock } from "lucide-react";
import { motion } from "framer-motion";

export function StepDateSelection() {
    const { state, setProfessional, setDate, setTimeSlot, nextStep, prevStep } = useBooking();
    const [loadingSlots, setLoadingSlots] = useState(false);
    const [availableSlots, setAvailableSlots] = useState<string[]>([]);
    // Mocking current month dates for demo
    const dates = Array.from({ length: 14 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() + i);
        return d;
    });

    // Fetch slots when date/pro changes
    useEffect(() => {
        if (state.date && state.professional && state.service) {
            setLoadingSlots(true);
            // MOCK API CALL
            fetch('/api/availability', {
                method: 'POST',
                body: JSON.stringify({
                    date: state.date.toISOString(),
                    professionalId: state.professional.id,
                    serviceId: state.service.id
                })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.slots) {
                        setAvailableSlots(data.slots.filter((s: any) => s.available).map((s: any) => s.time));
                    }
                })
                .catch(console.error)
                .finally(() => setLoadingSlots(false));
        }
    }, [state.date, state.professional, state.service]);

    return (
        <div className="grid lg:grid-cols-2 gap-12">
            {/* Left Col: Professional & Date */}
            <div className="space-y-8">
                <section>
                    <h3 className="text-white font-serif text-2xl mb-4">1. Escolha a Profissional</h3>
                    <div className="grid grid-cols-2 gap-4">
                        {PROFESSIONALS.map(prof => (
                            <div
                                key={prof.id}
                                onClick={() => setProfessional(prof)}
                                className={cn(
                                    "cursor-pointer rounded-xl border p-4 transition-all flex items-center gap-4",
                                    state.professional?.id === prof.id
                                        ? "bg-primary/20 border-primary"
                                        : "bg-white/5 border-white/10 hover:bg-white/10"
                                )}
                            >
                                <div className="relative w-12 h-12 rounded-full overflow-hidden">
                                    <Image src={prof.image} alt={prof.name} fill className="object-cover" />
                                </div>
                                <div>
                                    <h4 className="text-white font-medium">{prof.name}</h4>
                                    <p className="text-xs text-white/50">{prof.role}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                <section>
                    <h3 className="text-white font-serif text-2xl mb-4">2. Selecione a Data</h3>
                    <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-thin">
                        {dates.map(date => {
                            const isSelected = state.date?.getDate() === date.getDate();
                            return (
                                <button
                                    key={date.toISOString()}
                                    onClick={() => setDate(date)}
                                    className={cn(
                                        "min-w-[80px] p-3 rounded-xl border flex flex-col items-center justify-center transition-all",
                                        isSelected
                                            ? "bg-white text-black border-white"
                                            : "bg-white/5 border-white/10 text-white hover:border-white/30"
                                    )}
                                >
                                    <span className="text-xs uppercase opacity-60">
                                        {date.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '')}
                                    </span>
                                    <span className="text-xl font-bold font-serif">
                                        {date.getDate()}
                                    </span>
                                </button>
                            )
                        })}
                    </div>
                </section>
            </div>

            {/* Right Col: Time Slots */}
            <GlassCard>
                <div className="h-full flex flex-col">
                    <div className="flex items-center gap-2 mb-6 text-white/50">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm uppercase tracking-widest">Horários Disponíveis</span>
                    </div>

                    {!state.professional || !state.date ? (
                        <div className="flex-1 flex items-center justify-center text-white/20">
                            Selecione profissional e data para ver horários
                        </div>
                    ) : loadingSlots ? (
                        <div className="flex-1 flex items-center justify-center text-primary">
                            Carregando...
                        </div>
                    ) : (
                        <div className="grid grid-cols-3 gap-3 content-start">
                            {availableSlots.length > 0 ? availableSlots.map(time => (
                                <button
                                    key={time}
                                    onClick={() => setTimeSlot(time)}
                                    className={cn(
                                        "py-2 rounded-lg text-sm transition-all border",
                                        state.timeSlot === time
                                            ? "bg-primary text-black border-primary font-bold"
                                            : "bg-white/5 text-white border-white/10 hover:border-primary/50"
                                    )}
                                >
                                    {time}
                                </button>
                            )) : (
                                <p className="col-span-3 text-center text-white/40 py-10">
                                    Sem horários livres nesta data.
                                </p>
                            )}
                        </div>
                    )}

                    <div className="mt-8 pt-6 border-t border-white/10 flex justify-between">
                        <button onClick={prevStep} className="text-white/50 hover:text-white px-4">
                            Voltar
                        </button>
                        <button
                            disabled={!state.timeSlot}
                            onClick={nextStep}
                            className="bg-white text-black px-8 py-3 rounded-full font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 transition-colors flex items-center gap-2"
                        >
                            Continuar <ChevronRight className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </GlassCard>
        </div>
    );
}
