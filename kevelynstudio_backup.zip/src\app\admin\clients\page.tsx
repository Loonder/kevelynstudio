import { GlassCard } from "@/components/ui/glass-card";
import { db } from "@/lib/db";
import { clients } from "@/db/schema";
import { desc } from "drizzle-orm";
import { Search } from "lucide-react";

export const dynamic = 'force-dynamic';

export default async function ClientsPage() {
    const allClients = await db.select().from(clients).orderBy(desc(clients.createdAt));

    return (
        <div className="max-w-6xl mx-auto">
            <header className="mb-10 flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-serif text-white mb-2">Base de Clientes</h2>
                    <p className="text-white/50">{allClients.length} clientes cadastrados</p>
                </div>

                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                    <input
                        type="text"
                        placeholder="Buscar cliente..."
                        className="bg-white/5 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white focus:border-primary outline-none w-64"
                    />
                </div>
            </header>

            <GlassCard>
                <table className="w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/50 text-xs uppercase tracking-wider">
                        <tr>
                            <th className="p-4 font-medium">Nome</th>
                            <th className="p-4 font-medium">Email</th>
                            <th className="p-4 font-medium">Telefone</th>
                            <th className="p-4 font-medium">Preferências</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-white/80">
                        {allClients.map(client => (
                            <tr key={client.id} className="hover:bg-white/5 transition-colors">
                                <td className="p-4">
                                    <div className="font-medium text-white">{client.fullName}</div>
                                    <div className="text-xs text-white/30">ID: {client.id.slice(0, 8)}...</div>
                                </td>
                                <td className="p-4">{client.email}</td>
                                <td className="p-4">{client.phone}</td>
                                <td className="p-4">
                                    {client.sensoryPreferences ? (
                                        <div className="flex gap-2">
                                            <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs border border-primary/20">
                                                🎵 {client.sensoryPreferences.favoriteMusic || 'N/A'}
                                            </span>
                                            <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs border border-primary/20">
                                                🥂 {client.sensoryPreferences.drinkPreference || 'N/A'}
                                            </span>
                                        </div>
                                    ) : (
                                        <span className="text-white/30">-</span>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </GlassCard>
        </div>
    );
}
