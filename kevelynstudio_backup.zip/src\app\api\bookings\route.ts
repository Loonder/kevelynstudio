import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { appointments, clients } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { clientData, appointmentData, sensoryData } = body;

        // 1. Find or Create Client
        // Simplistic Logic: check email. In prod, maybe phone too.
        let clientId: string;

        const existingClient = await db.query.clients.findFirst({
            where: eq(clients.email, clientData.email)
        });

        if (existingClient) {
            clientId = existingClient.id;
            // Update prefs
            await db.update(clients)
                .set({
                    fullName: clientData.name,
                    phone: clientData.phone,
                    sensoryPreferences: {
                        favoriteMusic: sensoryData.musicGenre,
                        drinkPreference: sensoryData.drink
                    }
                })
                .where(eq(clients.id, clientId));
        } else {
            const [newClient] = await db.insert(clients).values({
                fullName: clientData.name,
                email: clientData.email,
                phone: clientData.phone,
                sensoryPreferences: {
                    favoriteMusic: sensoryData.musicGenre,
                    drinkPreference: sensoryData.drink
                }
            }).returning();
            clientId = newClient.id;
        }

        // 2. Create Appointment
        // Calculate End Time (simplified, assuming passed data is correct)
        const startTime = new Date(appointmentData.date); // Need to combine date + timeSlot properly in frontend or here
        // For this demo, let's assume 'date' is the full ISO string of the slot

        // Mock duration for now: 60 mins
        const endTime = new Date(startTime.getTime() + 60 * 60000);

        const [newAppointment] = await db.insert(appointments).values({
            clientId: clientId,
            professionalId: appointmentData.professionalId,
            serviceId: appointmentData.serviceId,
            startTime: startTime,
            endTime: endTime,
            status: 'pending'
        }).returning();

        return NextResponse.json({ success: true, appointment: newAppointment });

    } catch (error) {
        console.error("Booking API Error:", error);
        return NextResponse.json({ error: "Internal Server Error", details: error }, { status: 500 });
    }
}
