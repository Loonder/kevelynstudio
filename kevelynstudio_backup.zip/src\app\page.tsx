import { NavBar } from "@/components/layout/nav-bar";
import { Footer } from "@/components/layout/footer"; // New
import { HeroCinematic } from "@/components/sections/hero-cinematic";
import { BrandManifesto } from "@/components/sections/brand-manifesto";
import { ServicesList } from "@/components/sections/services-list";
import { MethodologySection } from "@/components/sections/methodology-section";
import { StudioGallery } from "@/components/sections/studio-gallery";
import { AcademyPromo } from "@/components/sections/academy-promo";
// import { LocationSection } from "@/components/sections/location-section"; // Moved to Footer
import { ResultsSection } from "@/components/features/results/results-section";
import { TeamEditorial } from "@/components/sections/team-editorial";
import { WhatsAppBubble } from "@/components/ui/whatsapp-bubble";
import { TestimonialsEditorial } from "@/components/sections/testimonials-editorial"; // New
import { FAQSection } from "@/components/sections/faq-section"; // New
import { getMethodologySteps } from "@/actions/cms-actions";

export default async function Home() {
  // Fetch methodology steps from database
  const methodologySteps = await getMethodologySteps();

  return (
    <>
      <NavBar />
      <WhatsAppBubble />
      <main>
        <HeroCinematic />
        <BrandManifesto />
        <ServicesList />
        <ResultsSection />
        <AcademyPromo />
        <TeamEditorial />
        <StudioGallery />
        <MethodologySection steps={methodologySteps} /> {/* Now database-driven! */}
        <TestimonialsEditorial />
        <FAQSection />
      </main>
      <Footer />
    </>
  );
}
