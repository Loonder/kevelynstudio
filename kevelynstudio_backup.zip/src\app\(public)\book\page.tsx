"use client";

import { NavBar } from "@/components/layout/nav-bar";
import { BookingProvider, useBooking } from "@/context/booking-context";
import { motion, AnimatePresence } from "framer-motion";
import { SERVICES } from "@/lib/data";
import { ServiceCard } from "@/components/features/services/service-card";
import { GlassCard } from "@/components/ui/glass-card";

import { StepDateSelection } from "@/components/features/booking/step-date-selection";
import { StepClientForm } from "@/components/features/booking/step-client-form";

// Step 1: Service Selection (Simplified for Demo)
function StepService() {
    const { setService, nextStep } = useBooking();

    return (
        <div className="grid md:grid-cols-3 gap-6">
            {SERVICES.map((service, i) => (
                <div key={service.id} onClick={() => { setService(service); nextStep(); }}>
                    <ServiceCard service={service} index={i} />
                </div>
            ))}
        </div>
    );
}

function BookingWizard() {
    const { state } = useBooking();

    return (
        <div className="container mx-auto px-6 py-32">
            <div className="mb-12">
                <span className="text-primary text-xs uppercase tracking-widest">Passo {state.step} de 3</span>
                <h1 className="text-4xl font-serif text-white mt-2">
                    {state.step === 1 && "Escolha sua Experiência"}
                    {state.step === 2 && "Data & Profissional"}
                    {state.step === 3 && "Finalização"}
                </h1>
            </div>

            <AnimatePresence mode="wait">
                <motion.div
                    key={state.step}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                >
                    {state.step === 1 && <StepService />}
                    {state.step === 2 && <StepDateSelection />}
                    {state.step === 3 && <StepClientForm />}
                </motion.div>
            </AnimatePresence>
        </div>
    );
}

export default function BookingPage() {
    return (
        <BookingProvider>
            <NavBar />
            <BookingWizard />
        </BookingProvider>
    );
}
