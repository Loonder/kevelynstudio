import { pgTable, text, timestamp, uuid, jsonb, integer, boolean } from "drizzle-orm/pg-core";
export * from "../lib/schema/cms";

// --- Users & Staff ---
export const professionals = pgTable("professionals", {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    slug: text("slug").unique().notNull(), // for URL
    role: text("role").notNull(),
    bio: text("bio"),
    instagramHandle: text("instagram_handle"),
    imageUrl: text("image_url"),
    isActive: boolean("is_active").default(true),
    createdAt: timestamp("created_at").defaultNow(),
});

// --- Services ---
export const services = pgTable("services", {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    description: text("description"),
    price: integer("price").notNull(), // in cents
    durationMinutes: integer("duration_minutes").notNull(),
    category: text("category").notNull(), // 'Lashes', 'Brows'
    imageUrl: text("image_url"),
    createdAt: timestamp("created_at").defaultNow(),
});

// --- Clients (SENSORY PREFS HERE) ---
export const clients = pgTable("clients", {
    id: uuid("id").primaryKey().defaultRandom(),
    fullName: text("full_name").notNull(),
    email: text("email").unique().notNull(),
    phone: text("phone").notNull(),

    // The 'Memory' of the studio
    sensoryPreferences: jsonb("sensory_preferences").$type<{
        favoriteMusic?: string; // Genre or Artist
        drinkPreference?: string; // Water, Champagne, Coffee
        temperature?: "warm" | "cool"; // optional
    }>(),

    createdAt: timestamp("created_at").defaultNow(),
});

// --- Appointments (The Core) ---
export const appointments = pgTable("appointments", {
    id: uuid("id").primaryKey().defaultRandom(),
    clientId: uuid("client_id").references(() => clients.id).notNull(),
    professionalId: uuid("professional_id").references(() => professionals.id).notNull(),
    serviceId: uuid("service_id").references(() => services.id).notNull(),

    startTime: timestamp("start_time").notNull(),
    endTime: timestamp("end_time").notNull(), // Calculated based on duration + buffer

    status: text("status").$type<"pending" | "confirmed" | "completed" | "cancelled">().default("pending"),

    // Integration Flags
    googleEventId: text("google_event_id"),

    createdAt: timestamp("created_at").defaultNow(),
});

// --- Course Platform ---

export const courses = pgTable("courses", {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    slug: text("slug").unique().notNull(),
    description: text("description"), // Markdown allowed
    price: integer("price").notNull(), // in cents
    coverImageUrl: text("cover_image_url"), // If null, UI uses gradient
    isPublished: boolean("is_published").default(false),
    createdAt: timestamp("created_at").defaultNow(),
});

export const modules = pgTable("modules", {
    id: uuid("id").primaryKey().defaultRandom(),
    courseId: uuid("course_id").references(() => courses.id, { onDelete: 'cascade' }).notNull(),
    title: text("title").notNull(),
    order: integer("order").notNull(), // 1, 2, 3...
    createdAt: timestamp("created_at").defaultNow(),
});

export const lessons = pgTable("lessons", {
    id: uuid("id").primaryKey().defaultRandom(),
    moduleId: uuid("module_id").references(() => modules.id, { onDelete: 'cascade' }).notNull(),
    title: text("title").notNull(),
    videoUrl: text("video_url"), // Vimeo/YouTube/BunnyJS
    durationMinutes: integer("duration_minutes"),
    isFreePreview: boolean("is_free_preview").default(false),
    order: integer("order").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
});

export const enrollments = pgTable("enrollments", {
    id: uuid("id").primaryKey().defaultRandom(),
    clientId: uuid("client_id").references(() => clients.id).notNull(),
    courseId: uuid("course_id").references(() => courses.id).notNull(),
    enrolledAt: timestamp("enrolled_at").defaultNow(),
    progress: integer("progress").default(0), // Percentage 0-100
});
