"use client";

import { cn } from "@/lib/cn";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useState } from "react";
import Link from "next/link";
import { Menu } from "lucide-react";

export function NavBar() {
    const { scrollY } = useScroll();
    const [isScrolled, setIsScrolled] = useState(false);

    useMotionValueEvent(scrollY, "change", (latest) => {
        setIsScrolled(latest > 50);
    });

    return (
        <motion.header
            className={cn(
                "fixed top-0 left-0 w-full z-50 transition-all duration-500",
                isScrolled ? "py-4 bg-background/80 backdrop-blur-md border-b border-white/5" : "py-8 bg-transparent"
            )}
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
            <div className="container mx-auto px-6 flex items-center justify-between">
                <Link href="/" className="group">
                    <h1 className="font-serif text-3xl font-bold tracking-widest text-white">
                        KEVELYN <span className="text-primary italic font-light group-hover:text-white transition-colors duration-300">STUDIO</span>
                    </h1>
                </Link>

                <nav className="hidden md:flex items-center gap-8 text-sm uppercase tracking-widest font-light text-white/80">
                    {["Atendimento", "Cursos", "Studio", "Contato"].map((item) => (
                        <Link key={item} href={`#${item.toLowerCase()}`} className="hover:text-primary transition-colors hover:font-normal">
                            {item}
                        </Link>
                    ))}
                    <button className="bg-white/10 px-6 py-2 rounded-full border border-white/20 hover:bg-primary hover:text-black hover:border-primary transition-all duration-300">
                        Agendar
                    </button>
                </nav>

                <button className="md:hidden text-white">
                    <Menu className="w-8 h-8" />
                </button>
            </div>
        </motion.header>
    );
}
