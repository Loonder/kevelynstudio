import { GlassCard } from "@/components/ui/glass-card";
import { db } from "@/lib/db";
import { services } from "@/db/schema";
import { desc } from "drizzle-orm";
import { Plus, Edit2 } from "lucide-react";

export const dynamic = 'force-dynamic';

export default async function ServicesPage() {
    const allServices = await db.select().from(services).orderBy(desc(services.createdAt));

    return (
        <div className="max-w-5xl mx-auto">
            <header className="mb-10 flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-serif text-white mb-2">Menu de Serviços</h2>
                    <p className="text-white/50">Gerencie preços, duração e visibilidade.</p>
                </div>

                <button className="flex items-center gap-2 bg-primary text-black px-4 py-2 rounded-lg font-medium hover:bg-primary-light transition-colors">
                    <Plus className="w-4 h-4" /> Novo Serviço
                </button>
            </header>

            <div className="grid gap-4">
                {allServices.map(service => (
                    <GlassCard key={service.id} className="flex items-center justify-between p-6">
                        <div>
                            <h3 className="text-xl text-white font-serif">{service.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-white/50 mt-1">
                                <span className="bg-white/5 px-2 py-1 rounded text-xs uppercase tracking-wider">{service.category}</span>
                                <span>{service.durationMinutes} min</span>
                            </div>
                        </div>

                        <div className="flex items-center gap-6">
                            <div className="text-right">
                                <span className="text-primary font-bold text-lg">
                                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(service.price / 100)}
                                </span>
                            </div>

                            <button className="p-2 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors">
                                <Edit2 className="w-4 h-4" />
                            </button>
                        </div>
                    </GlassCard>
                ))}
            </div>
        </div>
    );
}
