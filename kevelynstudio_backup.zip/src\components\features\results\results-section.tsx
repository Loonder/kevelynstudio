"use client";

import { BeforeAfterSlider } from "./before-after-slider";

export function ResultsSection() {
    return (
        <section className="py-24 bg-surface border-t border-white/5">
            <div className="container mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">

                {/* Text Area */}
                <div className="order-2 md:order-1">
                    <h2 className="font-serif text-3xl md:text-5xl text-white mb-6">
                        Precisão que <br />
                        <span className="text-primary">Transforma</span>
                    </h2>
                    <p className="text-white/60 mb-8 leading-relaxed">
                        Nossos procedimentos são minimamente invasivos e focados na naturalidade.
                        Utilizamos mapeamento facial avançado para garantir que o design complemente
                        sua estrutura óssea única.
                    </p>
                    <div className="grid grid-cols-2 gap-8 text-center md:text-left">
                        <div>
                            <span className="block text-3xl font-serif text-white mb-1">2k+</span>
                            <span className="text-xs uppercase tracking-widest text-white/40">Alunas Formadas</span>
                        </div>
                        <div>
                            <span className="block text-3xl font-serif text-white mb-1">5k+</span>
                            <span className="text-xs uppercase tracking-widest text-white/40">Procedimentos</span>
                        </div>
                    </div>
                </div>

                {/* Interactive Slider */}
                <div className="order-1 md:order-2">
                    <div className="relative p-2 bg-gradient-to-br from-white/10 to-transparent rounded-3xl border border-white/5">
                        <BeforeAfterSlider />
                    </div>
                </div>

            </div>
        </section>
    );
}
