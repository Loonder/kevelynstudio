"use client";

import { useTransition, useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { LuxuryButton } from "@/components/ui/luxury-button";
import { Input } from "@/components/ui/input";
import { login } from "./actions";
import { KeyRound } from "lucide-react";
import { motion } from "framer-motion";

export default function LoginPage() {
    const [isPending, startTransition] = useTransition();
    const [error, setError] = useState<string | null>(null);

    async function handleSubmit(formData: FormData) {
        setError(null);
        startTransition(async () => {
            const result = await login(formData);
            if (result?.error) {
                setError(result.error);
            }
        });
    }

    return (
        <div className="min-h-screen w-full bg-[#050505] flex items-center justify-center p-4 relative overflow-hidden">
            {/* Ambient Background */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-primary/20 blur-[150px] rounded-full mix-blend-screen opacity-30" />
                <div className="absolute top-[20%] -right-[10%] w-[40%] h-[60%] bg-purple-900/20 blur-[150px] rounded-full mix-blend-screen opacity-30" />
            </div>

            <GlassCard className="w-full max-w-md p-8 relative z-10 border-white/10 bg-black/40 backdrop-blur-2xl">
                <div className="mb-8 text-center space-y-2">
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ duration: 0.5 }}
                        className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/10"
                    >
                        <KeyRound className="w-5 h-5 text-primary" />
                    </motion.div>
                    <h1 className="font-serif text-3xl text-white tracking-tight">KEVELYN STUDIO</h1>
                    <p className="text-white/40 text-sm tracking-wide uppercase">Acesso Administrativo</p>
                </div>

                <form action={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                        <label htmlFor="email" className="text-xs uppercase tracking-wider text-white/50 block font-medium ml-1">Email</label>
                        <Input
                            id="email"
                            name="email"
                            type="email"
                            placeholder="admin@kevelynstudio.com"
                            required
                            className="bg-white/5 border-white/10 focus:border-primary/50 text-white placeholder:text-white/20"
                        />
                    </div>

                    <div className="space-y-2">
                        <label htmlFor="password" className="text-xs uppercase tracking-wider text-white/50 block font-medium ml-1">Senha</label>
                        <Input
                            id="password"
                            name="password"
                            type="password"
                            placeholder="••••••••"
                            required
                            className="bg-white/5 border-white/10 focus:border-primary/50 text-white placeholder:text-white/20"
                        />
                    </div>

                    {error && (
                        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center">
                            {error}
                        </div>
                    )}

                    <LuxuryButton
                        isLoading={isPending}
                        type="submit"
                        className="w-full justify-center"
                    >
                        Entrar no Sistema
                    </LuxuryButton>
                </form>
            </GlassCard>

            <div className="absolute bottom-8 text-center w-full text-white/20 text-xs tracking-widest uppercase">
                Sistema Seguro • Kevelyn Studio © {new Date().getFullYear()}
            </div>
        </div>
    );
}
