"use client";

import { useState } from "react";
import { GlassCard } from "@/components/ui/glass-card";
import { Play, CheckCircle, Clock } from "lucide-react";
import { ExperienceService } from "@/services/experience-service";
import { WelcomeOverlay } from "@/components/reception/welcome-overlay";
import { cn } from "@/lib/cn";

// Mock Data for "Today's Appointments" (Since we don't have real seeding yet)
const MOCK_APPOINTMENTS = [
    {
        id: "1",
        client: "Sofhia Loren",
        time: "14:00",
        service: "Nanopigmentação",
        status: "confirmed",
        prefs: { favoriteMusic: "pop" }
    },
    {
        id: "2",
        client: "Maria Silva",
        time: "15:30",
        service: "Lash Design",
        status: "confirmed",
        prefs: { favoriteMusic: "mpb" }
    },
    {
        id: "3",
        client: "Ana Paula",
        time: "17:00",
        service: "Micropigmentação Labial",
        status: "pending",
        prefs: { favoriteMusic: "jazz" }
    }
];

export default function ReceptionDashboard() {
    const [welcomeName, setWelcomeName] = useState<string | null>(null);

    const handleCheckIn = async (appt: typeof MOCK_APPOINTMENTS[0]) => {
        // Trigger the Experience
        await ExperienceService.welcomeClient(
            { name: appt.client, sensoryPreferences: appt.prefs },
            (name) => setWelcomeName(name) // Callback to show overlay
        );

        // Auto-hide overlay after 8 seconds (Simulating 'Show Time')
        setTimeout(() => {
            setWelcomeName(null);
        }, 8000);
    };

    return (
        <>
            <WelcomeOverlay
                isVisible={!!welcomeName}
                clientName={welcomeName || ""}
                onClose={() => setWelcomeName(null)}
            />

            <div className="container mx-auto px-6 py-12">
                <header className="mb-12 flex justify-between items-end">
                    <div>
                        <h1 className="text-3xl font-serif text-white">Recepção | Check-in</h1>
                        <p className="text-white/50">Gerenciamento de Experiência do Cliente</p>
                    </div>
                    <div className="text-right">
                        <p className="text-4xl text-primary font-serif">
                            {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                        <p className="text-xs uppercase tracking-widest text-white/40">
                            {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
                        </p>
                    </div>
                </header>

                <div className="grid gap-4">
                    {MOCK_APPOINTMENTS.map(appt => (
                        <GlassCard key={appt.id} className="flex items-center justify-between p-6">
                            <div className="flex items-center gap-6">
                                <div className="text-center w-16">
                                    <span className="block text-xl font-bold text-white">{appt.time}</span>
                                    <span className="text-[10px] uppercase text-white/30">Horário</span>
                                </div>

                                <div className="h-10 w-[1px] bg-white/10" />

                                <div>
                                    <h3 className="text-xl text-white font-serif">{appt.client}</h3>
                                    <p className="text-primary text-xs uppercase tracking-widest">{appt.service}</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                {appt.status === 'confirmed' ? (
                                    <button
                                        onClick={() => handleCheckIn(appt)}
                                        className="flex items-center gap-2 bg-gradient-to-r from-primary to-yellow-600 text-black px-6 py-3 rounded-full font-medium hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all transform hover:scale-105"
                                    >
                                        <Play className="w-4 h-4 fill-black" /> Iniciar Experiência
                                    </button>
                                ) : (
                                    <span className="text-white/30 text-sm italic pr-4">Aguardando Confirmação</span>
                                )}
                            </div>
                        </GlassCard>
                    ))}
                </div>
            </div>
        </>
    );
}
