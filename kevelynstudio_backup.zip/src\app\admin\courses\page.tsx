import { GlassCard } from "@/components/ui/glass-card";
import { db } from "@/lib/db";
import { courses } from "@/db/schema";
import { desc } from "drizzle-orm";
import { Plus, Edit, BookOpen } from "lucide-react";
import Link from "next/link";

export const dynamic = 'force-dynamic';

export default async function AdminCoursesPage() {
    const allCourses = await db.select().from(courses).orderBy(desc(courses.createdAt));

    return (
        <div className="max-w-5xl mx-auto">
            <header className="mb-10 flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-serif text-white mb-2">Academy & Cursos</h2>
                    <p className="text-white/50">Gerencie seus cursos presenciais e conteúdo.</p>
                </div>

                <button className="flex items-center gap-2 bg-primary text-black px-4 py-2 rounded-lg font-medium hover:bg-primary-light transition-colors">
                    <Plus className="w-4 h-4" /> Novo Curso
                </button>
            </header>

            <div className="grid gap-6">
                {allCourses.length === 0 ? (
                    <div className="text-center py-20 bg-white/5 rounded-2xl border border-white/5 mx-auto w-full">
                        <BookOpen className="w-12 h-12 text-white/20 mx-auto mb-4" />
                        <p className="text-white/50">Nenhum curso cadastrado ainda.</p>
                    </div>
                ) : (
                    allCourses.map(course => (
                        <GlassCard key={course.id} className="p-6 flex flex-col md:flex-row md:items-center gap-6 group hover:border-primary/30 transition-colors">
                            {/* Cover Preview */}
                            <div className="w-full md:w-48 h-32 bg-white/5 rounded-lg overflow-hidden relative shrink-0">
                                {course.coverImageUrl ? (
                                    <img src={course.coverImageUrl} alt={course.title} className="w-full h-full object-cover" />
                                ) : (
                                    <div className="w-full h-full bg-gradient-to-br from-surface to-neutral-900 flex items-center justify-center">
                                        <BookOpen className="w-8 h-8 text-white/20" />
                                    </div>
                                )}
                            </div>

                            <div className="flex-1">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h3 className="text-xl font-serif text-white group-hover:text-primary transition-colors">
                                            {course.title}
                                        </h3>
                                        <p className="text-sm text-white/50 mb-4 line-clamp-2 max-w-xl">
                                            {course.description || "Sem descrição."}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <span className={`px-2 py-1 rounded-full text-[10px] uppercase tracking-wide font-medium border ${course.isPublished ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-white/5 text-white/40 border-white/10'}`}>
                                            {course.isPublished ? 'Publicado' : 'Rascunho'}
                                        </span>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between mt-2 pt-4 border-t border-white/5">
                                    <div className="text-lg font-medium text-white">
                                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(course.price / 100)}
                                    </div>

                                    <Link
                                        href={`/admin/courses/${course.id}`}
                                        className="flex items-center gap-2 text-sm text-white/60 hover:text-primary transition-colors"
                                    >
                                        <Edit className="w-4 h-4" /> Editar Conteúdo
                                    </Link>
                                </div>
                            </div>
                        </GlassCard>
                    ))
                )}
            </div>
        </div>
    );
}
