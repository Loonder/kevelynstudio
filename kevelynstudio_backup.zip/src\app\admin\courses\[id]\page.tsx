import { GlassCard } from "@/components/ui/glass-card";
import { db } from "@/lib/db";
import { courses, modules, lessons } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { ChevronLeft, Plus, Video, FileText, GripVertical } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = 'force-dynamic';

export default async function CourseEditorPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;

    // Fetch Course
    const course = await db.query.courses.findFirst({
        where: eq(courses.id, id)
    });

    if (!course) return notFound();

    // Fetch Modules & Lessons
    // structured data query would be better but separate queries allow standard sorting
    const courseModules = await db.select().from(modules).where(eq(modules.courseId, id)).orderBy(asc(modules.order));

    // For now, simple fetch. In a real app we might group them.
    // Let's just mock the collapsible UI structure for visual verification as requested.

    return (
        <div className="max-w-5xl mx-auto pb-20">
            {/* Header */}
            <div className="mb-8">
                <Link href="/admin/courses" className="inline-flex items-center gap-2 text-white/40 hover:text-white mb-6 text-sm transition-colors">
                    <ChevronLeft className="w-4 h-4" /> Voltar para Cursos
                </Link>

                <div className="flex justify-between items-start">
                    <div>
                        <h1 className="text-3xl font-serif text-white mb-2">{course.title}</h1>
                        <p className="text-white/50">Editando Grade Curricular</p>
                    </div>
                    <div className="flex gap-3">
                        <button className="px-4 py-2 rounded-lg bg-white/5 text-white  hover:bg-white/10 transition-colors text-sm">
                            Configurações
                        </button>
                        <button className="px-4 py-2 rounded-lg bg-primary text-black font-medium hover:bg-primary-light transition-colors text-sm">
                            Salvar Alterações
                        </button>
                    </div>
                </div>
            </div>

            {/* Curriculum Builder */}
            <div className="space-y-6">

                {/* Module List */}
                {courseModules.length === 0 ? (
                    <GlassCard className="p-12 text-center border-dashed border-white/20">
                        <p className="text-white/40 mb-4">Este curso ainda não tem módulos.</p>
                        <button className="inline-flex items-center gap-2 text-primary hover:text-white transition-colors">
                            <Plus className="w-5 h-5" /> Adicionar Primeiro Módulo
                        </button>
                    </GlassCard>
                ) : (
                    courseModules.map((module) => (
                        <div key={module.id} className="bg-surface border border-white/10 rounded-xl overflow-hidden">
                            <div className="bg-white/5 p-4 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <GripVertical className="w-5 h-5 text-white/20 cursor-move" />
                                    <h3 className="font-medium text-white">{module.title}</h3>
                                </div>
                                <div className="flex gap-2">
                                    <button className="p-1 text-white/40 hover:text-white"><Plus className="w-4 h-4" /></button>
                                </div>
                            </div>

                            {/* Lessons Area */}
                            <div className="p-2 space-y-1">
                                {/* Placeholder for Lessons */}
                                <div className="py-2 px-8 text-sm text-white/30 italic">
                                    Nenhuma aula neste módulo ainda.
                                </div>
                            </div>
                        </div>
                    ))
                )}

                <button className="w-full py-4 border-2 border-dashed border-white/10 rounded-xl text-white/40 hover:text-white hover:border-white/20 transition-all flex items-center justify-center gap-2">
                    <Plus className="w-5 h-5" /> Adicionar Módulo
                </button>
            </div>
        </div>
    );
}
