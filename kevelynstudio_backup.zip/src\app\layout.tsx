import type { Metadata } from "next";
import { Cormorant_Garamond, Outfit } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/cn";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  variable: "--font-cormorant",
  weight: ["300", "400", "500", "600", "700"],
  display: "swap"
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
  weight: ["300", "400", "500", "600"],
  display: "swap"
});

export const metadata: Metadata = {
  title: "Kevelyn Studio | Excellence in Beauty",
  description: "Premium Lash & Brow Design Studio. Experience the art of beauty.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="scroll-smooth">
      <body
        suppressHydrationWarning
        className={cn(
          "min-h-screen font-sans bg-background text-text-primary selection:bg-primary/30 selection:text-white",
          cormorant.variable,
          outfit.variable
        )}>
        {/* Lenis provider will be added here loosely or via a client component wrapper */}
        <main className="relative flex flex-col w-full">
          {children}
        </main>
      </body>
    </html>
  );
}
