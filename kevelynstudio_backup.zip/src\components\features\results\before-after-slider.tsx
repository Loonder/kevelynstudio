"use client";

import { motion, useMotionValue, useTransform } from "framer-motion";
import Image from "next/image";
import { useState, useRef, useEffect } from "react";
import { GripVertical } from "lucide-react";

export function BeforeAfterSlider() {
    const [width, setWidth] = useState(0);
    const containerRef = useRef<HTMLDivElement>(null);
    const x = useMotionValue(0);

    useEffect(() => {
        if (containerRef.current) {
            setWidth(containerRef.current.offsetWidth);
            x.set(containerRef.current.offsetWidth / 2);
        }
    }, [x]);

    const clipPath = useTransform(x, (value) => `inset(0 ${width - value}px 0 0)`);

    return (
        <div ref={containerRef} className="relative w-full aspect-[4/5] md:aspect-video rounded-2xl overflow-hidden cursor-ew-resize select-none">
            {/* Before Image (Background) - Grayscale to simulate 'Before' */}
            <div className="absolute inset-0">
                <Image
                    src="/assets/images/hero-parallax-fg.jpg"
                    alt="Before Procedure"
                    fill
                    className="object-cover grayscale brightness-75 contrast-50"
                />
                <div className="absolute top-8 left-8 bg-black/50 backdrop-blur px-4 py-1 rounded-full border border-white/10">
                    <span className="text-xs uppercase tracking-widest text-white">Antes</span>
                </div>
            </div>

            {/* After Image (Foreground) - Clipped */}
            <motion.div style={{ clipPath }} className="absolute inset-0">
                <Image
                    src="/assets/images/hero-parallax-fg.jpg"
                    alt="After Procedure"
                    fill
                    className="object-cover"
                />
                <div className="absolute top-8 right-8 bg-black/50 backdrop-blur px-4 py-1 rounded-full border border-white/10">
                    <span className="text-xs uppercase tracking-widest text-primary font-bold">Depois</span>
                </div>
            </motion.div>

            {/* Slider Handle */}
            <motion.div
                drag="x"
                dragConstraints={containerRef}
                dragElastic={0}
                dragMomentum={false}
                style={{ x }}
                className="absolute top-0 bottom-0 w-1 bg-white/50 cursor-ew-resize z-10 flex items-center justify-center hover:bg-white transition-colors"
            >
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-xl">
                    <GripVertical className="w-5 h-5 text-black" />
                </div>
            </motion.div>
        </div>
    );
}
