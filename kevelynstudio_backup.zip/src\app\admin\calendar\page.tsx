export default function AdminCalendarPage() {
    return (
        <div className="p-10 text-white text-center">
            <h1 className="text-2xl font-serif mb-4">Calendário Completo</h1>
            <p className="text-white/50">Em construção...</p>
        </div>
    )
}
