"use client";

import { motion, AnimatePresence } from "framer-motion";

export function WelcomeOverlay({
    isVisible,
    clientName,
    onClose
}: {
    isVisible: boolean;
    clientName: string;
    onClose?: () => void
}) {
    return (
        <AnimatePresence>
            {isVisible && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1 }} // Slow fade
                    className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-8 cursor-pointer"
                    onClick={onClose}
                >
                    {/* Background Atmosphere */}
                    <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-primary/5 lazy-animate-pulse" />

                    <motion.div
                        initial={{ scale: 0.9, y: 30, opacity: 0 }}
                        animate={{ scale: 1, y: 0, opacity: 1 }}
                        exit={{ scale: 1.1, opacity: 0 }}
                        transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
                        className="text-center relative z-10"
                    >
                        <motion.h2
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.5, duration: 2 }}
                            className="text-primary text-xl md:text-2xl uppercase tracking-[0.5em] mb-8 font-light"
                        >
                            Bem-vinda ao Kevelyn Studio
                        </motion.h2>

                        <h1 className="font-serif text-6xl md:text-8xl text-white drop-shadow-2xl">
                            {clientName} <span className="text-primary">✨</span>
                        </h1>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
}
