import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@/db/schema';
import dotenv from 'dotenv';
dotenv.config();

// CRITICAL FIX: Use DIRECT_URL instead of DATABASE_URL
// The Transaction Pooler (DATABASE_URL, port 6543) doesn't support DDL and may not see newly created tables
// DIRECT_URL (port 5432) gives us direct access to the database where we ran the SQL reset script
const connectionString = process.env.DIRECT_URL || process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/kevelyn_studio';

console.log('🔌 Connecting to database:', connectionString?.split('@')[1]?.split('?')[0] || 'localhost');

const client = postgres(connectionString, {
    max: 1,
    ssl: 'prefer', // Use 'prefer' for better Supabase compatibility  
    prepare: false, // Required for connection pooling compatibility
    idle_timeout: 20,
    connect_timeout: 10,
});

export const db = drizzle(client, { schema });
