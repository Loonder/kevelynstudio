import { GlassCard } from "@/components/ui/glass-card";
import { db } from "@/lib/db";
import { appointments, clients, services, professionals } from "@/db/schema";
import { desc, eq, gte, and, sql } from "drizzle-orm";
import { format, startOfDay, endOfDay, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/cn";

// Force dynamic to fetch fresh data on every request
export const dynamic = 'force-dynamic';

export default async function AdminDashboard() {
    const now = new Date();
    const todayStart = startOfDay(now);
    const todayEnd = endOfDay(now);
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    // Fetch upcoming appointments
    const upcomingAppointments = await db.select({
        id: appointments.id,
        startTime: appointments.startTime,
        status: appointments.status,
        clientName: clients.fullName,
        serviceTitle: services.title,
        professionalName: professionals.name,
    })
        .from(appointments)
        .leftJoin(clients, eq(appointments.clientId, clients.id))
        .leftJoin(services, eq(appointments.serviceId, services.id))
        .leftJoin(professionals, eq(appointments.professionalId, professionals.id))
        .orderBy(desc(appointments.startTime))
        .limit(10);

    // Calculate stats
    const todayAppointments = await db.select({ count: sql<number>`cast(count(*) as integer)` })
        .from(appointments)
        .where(and(
            gte(appointments.startTime, todayStart),
            sql`${appointments.startTime} <= ${todayEnd}`
        ));

    const monthlyRevenue = await db.select({
        total: sql<number>`COALESCE(cast(SUM(${services.price}) as integer), 0)`
    })
        .from(appointments)
        .leftJoin(services, eq(appointments.serviceId, services.id))
        .where(and(
            eq(appointments.status, 'completed'),
            gte(appointments.startTime, monthStart),
            sql`${appointments.startTime} <= ${monthEnd}`
        ));

    const newClientsThisMonth = await db.select({ count: sql<number>`cast(count(*) as integer)` })
        .from(clients)
        .where(and(
            gte(clients.createdAt, monthStart),
            sql`${clients.createdAt} <= ${monthEnd}`
        ));

    const todayCount = Number(todayAppointments[0]?.count) || 0;
    const revenueTotal = Number(monthlyRevenue[0]?.total) || 0;
    const newClientsCount = Number(newClientsThisMonth[0]?.count) || 0;

    return (
        <div className="max-w-7xl mx-auto">
            <header className="mb-10 flex justify-between items-end">
                <div>
                    <h2 className="text-3xl font-serif text-white mb-2">Visão Geral</h2>
                    <p className="text-white/50">Bem-vinda de volta, Kevelyn.</p>
                </div>
                <div>
                    <span className="text-sm text-white/40 bg-white/5 border border-white/10 px-4 py-2 rounded-full">
                        {format(new Date(), "EEEE, d 'de' MMMM", { locale: ptBR })}
                    </span>
                </div>
            </header>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                <GlassCard className="p-6">
                    <p className="text-white/50 text-xs uppercase tracking-widest mb-2">Agendamentos Hoje</p>
                    <p className="text-3xl font-serif text-white">{todayCount}</p>
                </GlassCard>
                <GlassCard className="p-6">
                    <p className="text-white/50 text-xs uppercase tracking-widest mb-2">Faturamento (Mês)</p>
                    <p className="text-3xl font-serif text-primary">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(revenueTotal / 100)}
                    </p>
                </GlassCard>
                <GlassCard className="p-6">
                    <p className="text-white/50 text-xs uppercase tracking-widest mb-2">Novos Clientes</p>
                    <p className="text-3xl font-serif text-white">{newClientsCount}</p>
                </GlassCard>
            </div>

            <h3 className="text-xl text-white font-serif mb-6">Próximos Agendamentos</h3>

            <GlassCard className="overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/50 text-xs uppercase tracking-wider">
                            <tr>
                                <th className="p-4 font-medium">Horário</th>
                                <th className="p-4 font-medium">Cliente</th>
                                <th className="p-4 font-medium">Serviço</th>
                                <th className="p-4 font-medium">Profissional</th>
                                <th className="p-4 font-medium">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-white/80">
                            {upcomingAppointments.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="p-8 text-center text-white/30 italic">
                                        Nenhum agendamento encontrado.
                                    </td>
                                </tr>
                            ) : (
                                upcomingAppointments.map((appt) => (
                                    <tr key={appt.id} className="hover:bg-white/5 transition-colors">
                                        <td className="p-4 text-white">
                                            {format(new Date(appt.startTime), "HH:mm")}
                                            <span className="block text-xs text-white/40">
                                                {format(new Date(appt.startTime), "dd/MM")}
                                            </span>
                                        </td>
                                        <td className="p-4 font-medium text-white">{appt.clientName}</td>
                                        <td className="p-4">{appt.serviceTitle}</td>
                                        <td className="p-4">{appt.professionalName}</td>
                                        <td className="p-4">
                                            <span className={cn(
                                                "px-2 py-1 rounded-full text-[10px] uppercase tracking-wide font-medium",
                                                appt.status === 'confirmed' && "bg-green-500/20 text-green-400",
                                                appt.status === 'pending' && "bg-yellow-500/20 text-yellow-400",
                                                appt.status === 'cancelled' && "bg-red-500/20 text-red-400",
                                                appt.status === 'completed' && "bg-blue-500/20 text-blue-400",
                                            )}>
                                                {appt.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </GlassCard>
        </div>
    );
}
